# Website Rutan Kelas II Masohi

## Isi folder ini
- `index.html` — struktur & isi halaman (Beranda, Profil, Berita, Galeri, Produk Binaan, Kunjungan, Kontak)
- `style.css` — tampilan/desain
- `script.js` — untuk tombol menu di tampilan HP
- (folder `images/` belum ada — buat folder ini dan taruh foto di dalamnya, lalu sesuaikan nama file di index.html)

## Cara upload ke GitHub Pages
1. Buka repository kamu di GitHub
2. Klik link "uploading an existing file"
3. Drag & drop ketiga file ini (index.html, style.css, script.js) sekaligus
4. Klik "Commit changes"
5. Masuk ke Settings > Pages > Source pilih "Deploy from a branch", branch "main", folder "/root" > Save
6. Tunggu beberapa menit, website bisa dibuka di link yang muncul

## Cara menambah bagian baru (misalnya sudah ada tapi mau nambah lagi)
1. Klik file `index.html` di GitHub
2. Klik ikon pensil (Edit)
3. Cari bagian yang polanya mirip dengan yang mau ditambah, copy-paste struktur `<section>...</section>`-nya, lalu ganti isinya
4. Scroll ke bawah, klik "Commit changes"

## Cara ganti isi teks/foto
- Teks: langsung edit di antara tag HTML, misalnya ganti tulisan "Isi visi instansi di sini..."
- Foto: upload foto ke folder `images/`, lalu ganti bagian `<div class="thumb">Foto Kegiatan</div>` dengan `<img src="images/namafoto.jpg">`
